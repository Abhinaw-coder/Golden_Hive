import { useState } from "react";
import { useTheme } from "@/hooks/useTheme";

export default function Navigation() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-40 bg-background/80 dark:bg-background/80 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <div 
          className="text-2xl font-black text-primary tracking-tight cursor-pointer"
          onClick={() => scrollToSection("home")}
        >
          GOLDEN HIVE
        </div>
        
        <div className="hidden md:flex items-center space-x-8">
          <button 
            onClick={() => scrollToSection("home")}
            className="text-foreground hover:text-primary transition-colors font-medium"
          >
            Home
          </button>
          <button 
            onClick={() => scrollToSection("about")}
            className="text-foreground hover:text-primary transition-colors font-medium"
          >
            About
          </button>
          <button 
            onClick={() => scrollToSection("products")}
            className="text-foreground hover:text-primary transition-colors font-medium"
          >
            Products
          </button>

          <button 
            onClick={() => scrollToSection("benefits")}
            className="text-foreground hover:text-primary transition-colors font-medium"
          >
            Benefits
          </button>
          <button 
            onClick={() => scrollToSection("charts")}
            className="text-foreground hover:text-primary transition-colors font-medium"
          >
            Analytics
          </button>
          <button 
            onClick={() => scrollToSection("reviews")}
            className="text-foreground hover:text-primary transition-colors font-medium"
          >
            Reviews
          </button>
          <button 
            onClick={() => scrollToSection("contact")}
            className="text-foreground hover:text-primary transition-colors font-medium"
          >
            Contact
          </button>
        </div>

        <div className="flex items-center space-x-4">
          <button 
            onClick={toggleTheme}
            className="p-2 rounded-full bg-secondary text-primary hover:bg-secondary/80 transition-colors"
          >
            {theme === "light" ? (
              <i className="fas fa-moon"></i>
            ) : (
              <i className="fas fa-sun"></i>
            )}
          </button>
          <button 
            onClick={() => scrollToSection("contact")}
            className="bg-primary hover:bg-primary/80 text-primary-foreground px-6 py-2 rounded-full font-medium transition-colors duration-300 animate-glow"
          >
            LET'S TALK
          </button>
          <button 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 text-foreground"
          >
            <i className="fas fa-bars"></i>
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div 
        className={`md:hidden absolute top-full left-0 right-0 bg-background border-b border-border transition-all duration-300 ${
          isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}
      >
        <div className="px-6 py-4 space-y-4">
          <button 
            onClick={() => scrollToSection("home")}
            className="block w-full text-left text-foreground hover:text-primary transition-colors font-medium"
          >
            Home
          </button>
          <button 
            onClick={() => scrollToSection("about")}
            className="block w-full text-left text-foreground hover:text-primary transition-colors font-medium"
          >
            About
          </button>
          <button 
            onClick={() => scrollToSection("products")}
            className="block w-full text-left text-foreground hover:text-primary transition-colors font-medium"
          >
            Products
          </button>
          <button 
            onClick={() => scrollToSection("reviews")}
            className="block w-full text-left text-foreground hover:text-primary transition-colors font-medium"
          >
            Reviews
          </button>
          <button 
            onClick={() => scrollToSection("contact")}
            className="block w-full text-left text-foreground hover:text-primary transition-colors font-medium"
          >
            Contact
          </button>
        </div>
      </div>
    </nav>
  );
}
