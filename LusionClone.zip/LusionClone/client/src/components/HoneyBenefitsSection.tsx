import { useEffect, useRef } from "react";

export default function HoneyBenefitsSection() {
  const containerRef = useRef<HTMLDivElement>(null);

  const benefitsData = [
    {
      title: "Natural Energy Boost",
      description: "Honey provides quick, sustained energy through natural fructose and glucose. Perfect for athletes and active lifestyles without the crash of processed sugars.",
      icon: "⚡",
      category: "Energy & Performance"
    },
    {
      title: "Immune System Support",
      description: "Rich in antioxidants, enzymes, and antimicrobial compounds that strengthen your body's natural defenses against illness and infection.",
      icon: "🛡️",
      category: "Health & Immunity"
    },
    {
      title: "Digestive Wellness",
      description: "Prebiotic properties promote healthy gut bacteria, improve digestion, and soothe stomach irritation naturally.",
      icon: "🌿",
      category: "Digestive Health"
    },
    {
      title: "Skin & Beauty",
      description: "Natural humectant properties hydrate and heal skin, reduce inflammation, and provide anti-aging benefits when consumed regularly.",
      icon: "✨",
      category: "Beauty & Wellness"
    }
  ];

  useEffect(() => {
    const script1 = document.createElement('script');
    script1.src = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js';
    document.head.appendChild(script1);

    script1.onload = () => {
      const script2 = document.createElement('script');
      script2.src = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js';
      document.head.appendChild(script2);

      script2.onload = () => {
        if (window.gsap && window.ScrollTrigger) {
          window.gsap.registerPlugin(window.ScrollTrigger);
          
          setTimeout(() => {
            const benefitCards = document.querySelectorAll('.benefit-card');
            
            window.gsap.set(benefitCards, {
              y: 50,
              opacity: 0,
              scale: 0.9
            });

            window.ScrollTrigger.create({
              trigger: '#benefits',
              start: "top 70%",
              onEnter: () => {
                window.gsap.to(benefitCards, {
                  y: 0,
                  opacity: 1,
                  scale: 1,
                  duration: 0.8,
                  stagger: 0.2,
                  ease: "back.out(1.7)"
                });
              }
            });
          }, 500);
        }
      };
    };
  }, []);

  return (
    <section id="benefits" className="py-32 bg-gradient-to-br from-amber-50 via-honey-50 to-orange-50 dark:from-gray-900 dark:via-gray-950 dark:to-gray-900 relative overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-20 right-10 w-6 h-6 bg-amber-400/20 rounded-full animate-float"></div>
        <div className="absolute bottom-32 left-20 w-8 h-8 bg-orange-400/20 rounded-full animate-float" style={{animationDelay: '-3s'}}></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <div className="text-sm font-semibold text-primary tracking-widest uppercase mb-4">Health & Wellness</div>
          <h2 className="text-5xl md:text-6xl font-black text-foreground mb-6">
            Honey
            <span className="block honey-text-gradient">Benefits</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Discover the incredible health benefits of pure honey, nature's most powerful superfood for your body and mind.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {benefitsData.map((item, index) => (
            <div key={index} className="benefit-card bg-card/80 backdrop-blur-sm rounded-2xl p-8 shadow-lg border border-primary/20 hover:shadow-xl transition-all duration-300">
              <div className="flex items-start gap-6">
                <div className="flex-shrink-0">
                  <span className="text-4xl block">{item.icon}</span>
                </div>
                <div className="flex-1">
                  <div className="text-sm font-semibold text-primary mb-2">{item.category}</div>
                  <h3 className="text-xl font-bold text-foreground mb-3">{item.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{item.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-20">
          <div className="bg-gradient-to-r from-primary to-orange-400 rounded-3xl p-12 text-white">
            <h3 className="text-3xl md:text-4xl font-black mb-6">
              Experience Nature's Perfect Medicine
            </h3>
            <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
              Transform your health with our premium, raw honey collection
            </p>
            <button className="bg-white text-primary px-8 py-4 rounded-full font-semibold text-lg hover:bg-white/90 transition-all duration-300 transform hover:scale-105 shadow-lg">
              Shop Our Collection
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}