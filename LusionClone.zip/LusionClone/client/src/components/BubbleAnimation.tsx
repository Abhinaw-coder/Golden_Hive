import { useEffect } from "react";

export default function BubbleAnimation() {
  useEffect(() => {
    const container = document.getElementById("bubble-container");
    if (!container) return;

    // Create bubbles
    for (let i = 0; i < 8; i++) {
      const bubble = document.createElement("div");
      bubble.className = "bubble";
      
      // Random size and position
      const size = Math.random() * 100 + 50;
      bubble.style.width = `${size}px`;
      bubble.style.height = `${size}px`;
      bubble.style.left = `${Math.random() * 100}%`;
      bubble.style.top = `${Math.random() * 100}%`;
      bubble.style.animationDelay = `${Math.random() * 8}s`;
      bubble.style.animationDuration = `${8 + Math.random() * 4}s`;
      
      container.appendChild(bubble);
    }

    return () => {
      if (container) {
        container.innerHTML = "";
      }
    };
  }, []);

  return (
    <div 
      id="bubble-container" 
      className="absolute inset-0 pointer-events-none z-10"
    ></div>
  );
}
