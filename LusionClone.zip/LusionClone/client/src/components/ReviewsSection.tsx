export default function ReviewsSection() {
  return (
    <section id="reviews" className="py-32 bg-gradient-to-br from-honey-50 via-orange-50 to-yellow-50 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16 animate-fadeInUp">
          <div className="text-sm font-semibold text-primary tracking-widest uppercase mb-4">Customer Love</div>
          <h2 className="text-5xl md:text-6xl font-black text-foreground mb-6">
            What Our Customers
            <span className="block honey-text-gradient">Are Saying</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Review Card 1 */}
          <div className="bg-card rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 animate-fadeInUp">
            <div className="flex text-primary mb-4">
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
            </div>
            
            <p className="text-muted-foreground mb-6 leading-relaxed">
              "The quality is absolutely incredible! You can taste the difference - it's like nothing I've ever had before. Pure liquid gold!"
            </p>
            
            <div className="flex items-center">
              <img 
                src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=64&h=64" 
                alt="Happy customer Sarah enjoying honey with genuine satisfaction" 
                className="w-12 h-12 rounded-full mr-4" 
              />
              <div>
                <div className="font-semibold text-foreground">Sarah Johnson</div>
                <div className="text-sm text-muted-foreground">Verified Customer</div>
              </div>
            </div>
          </div>

          {/* Review Card 2 */}
          <div className="bg-card rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 animate-fadeInUp" style={{animationDelay: '0.2s'}}>
            <div className="flex text-primary mb-4">
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
            </div>
            
            <p className="text-muted-foreground mb-6 leading-relaxed">
              "Been ordering from Golden Hive for years. The consistency and purity is unmatched. My whole family loves it!"
            </p>
            
            <div className="flex items-center">
              <img 
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=64&h=64" 
                alt="Satisfied long-term customer Michael with appreciation and trust" 
                className="w-12 h-12 rounded-full mr-4" 
              />
              <div>
                <div className="font-semibold text-foreground">Michael Chen</div>
                <div className="text-sm text-muted-foreground">Loyal Customer</div>
              </div>
            </div>
          </div>

          {/* Review Card 3 */}
          <div className="bg-card rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 animate-fadeInUp" style={{animationDelay: '0.4s'}}>
            <div className="flex text-primary mb-4">
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
            </div>
            
            <p className="text-muted-foreground mb-6 leading-relaxed">
              "Perfect for my tea and baking. The flavor profile is complex and rich. Highly recommend to anyone who appreciates quality!"
            </p>
            
            <div className="flex items-center">
              <img 
                src="https://images.unsplash.com/photo-1494790108755-2616b612b672?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=64&h=64" 
                alt="Professional chef Emma using honey in culinary applications" 
                className="w-12 h-12 rounded-full mr-4" 
              />
              <div>
                <div className="font-semibold text-foreground">Emma Rodriguez</div>
                <div className="text-sm text-muted-foreground">Chef & Food Blogger</div>
              </div>
            </div>
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 text-center animate-fadeInUp">
          <div>
            <div className="text-4xl font-black text-primary mb-2">98%</div>
            <div className="text-muted-foreground">Customer Satisfaction</div>
          </div>
          
          <div>
            <div className="text-4xl font-black text-primary mb-2">5k+</div>
            <div className="text-muted-foreground">Happy Reviews</div>
          </div>
          
          <div>
            <div className="text-4xl font-black text-primary mb-2">24/7</div>
            <div className="text-muted-foreground">Customer Support</div>
          </div>
          
          <div>
            <div className="text-4xl font-black text-primary mb-2">100%</div>
            <div className="text-muted-foreground">Quality Guarantee</div>
          </div>
        </div>
      </div>
    </section>
  );
}
