import MarblingCard from "./MarblingCard";

export default function ProductsSection() {
  return (
    <section id="products" className="py-32 bg-card relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16 animate-fadeInUp">
          <div className="text-sm font-semibold text-primary tracking-widest uppercase mb-4">Our Premium Collection</div>
          <h2 className="text-5xl md:text-6xl font-black text-foreground mb-6">
            Artisan Honey
            <span className="block honey-text-gradient">Varieties</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Each jar tells a story of dedicated craftsmanship and natural purity
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 items-stretch">
          {/* Product Card 1 */}
          <MarblingCard className="group bg-gradient-to-br from-honey-50 to-orange-50 dark:from-gray-800 dark:to-gray-700 rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 animate-fadeInUp flex flex-col">
            <div className="relative mb-6">
              <img 
                src="https://images.unsplash.com/photo-1587049352846-4a222e784d38?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300" 
                alt="Premium wildflower honey jar with elegant labeling" 
                className="w-full h-48 object-cover rounded-2xl" 
              />
              <div className="absolute top-4 right-4 bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-semibold">
                Best Seller
              </div>
            </div>
            
            <div className="flex-1 flex flex-col">
              <h3 className="text-2xl font-bold text-foreground mb-3">Wildflower Honey</h3>
              <p className="text-muted-foreground mb-4 leading-relaxed flex-1">
                A complex blend from diverse wildflower meadows, offering rich floral notes and natural sweetness.
              </p>
              
              <div className="flex items-center justify-between mb-6">
                <span className="text-3xl font-bold text-primary">$24.99</span>
                <div className="flex text-primary">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                </div>
              </div>
              
              <button className="w-full bg-primary hover:bg-primary/80 text-primary-foreground py-3 rounded-2xl font-semibold transition-colors duration-300 group-hover:shadow-lg mt-auto">
                Add to Cart
              </button>
            </div>
          </MarblingCard>

          {/* Product Card 2 */}
          <MarblingCard className="group bg-gradient-to-br from-honey-50 to-orange-50 dark:from-gray-800 dark:to-gray-700 rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 animate-fadeInUp flex flex-col">
            <div className="relative mb-6">
              <img 
                src="https://images.unsplash.com/photo-1471943311424-646960669fbc?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300" 
                alt="Raw organic honey with crystallization and natural texture" 
                className="w-full h-48 object-cover rounded-2xl" 
              />
              <div className="absolute top-4 right-4 bg-green-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                Organic
              </div>
            </div>
            
            <div className="flex-1 flex flex-col">
              <h3 className="text-2xl font-bold text-foreground mb-3">Raw Clover Honey</h3>
              <p className="text-muted-foreground mb-4 leading-relaxed flex-1">
                Unprocessed and unfiltered, maintaining all natural enzymes and beneficial properties.
              </p>
              
              <div className="flex items-center justify-between mb-6">
                <span className="text-3xl font-bold text-primary">$32.99</span>
                <div className="flex text-primary">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                </div>
              </div>
              
              <button className="w-full bg-primary hover:bg-primary/80 text-primary-foreground py-3 rounded-2xl font-semibold transition-colors duration-300 group-hover:shadow-lg mt-auto">
                Add to Cart
              </button>
            </div>
          </MarblingCard>

          {/* Product Card 3 */}
          <MarblingCard className="group bg-gradient-to-br from-honey-50 to-orange-50 dark:from-gray-800 dark:to-gray-700 rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 animate-fadeInUp flex flex-col">
            <div className="relative mb-6">
              <img 
                src="https://images.unsplash.com/photo-1558642894-148630d45f67?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300" 
                alt="Luxury honey gift set with multiple varieties and premium packaging" 
                className="w-full h-48 object-cover rounded-2xl" 
              />
              <div className="absolute top-4 right-4 bg-purple-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                Limited
              </div>
            </div>
            
            <div className="flex-1 flex flex-col">
              <h3 className="text-2xl font-bold text-foreground mb-3">Premium Gift Set</h3>
              <p className="text-muted-foreground mb-4 leading-relaxed flex-1">
                Curated collection of our finest honey varieties, perfect for gifting or special occasions.
              </p>
              
              <div className="flex items-center justify-between mb-6">
                <span className="text-3xl font-bold text-primary">$89.99</span>
                <div className="flex text-primary">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                </div>
              </div>
              
              <button className="w-full bg-primary hover:bg-primary/80 text-primary-foreground py-3 rounded-2xl font-semibold transition-colors duration-300 group-hover:shadow-lg mt-auto">
                Add to Cart
              </button>
            </div>
          </MarblingCard>
        </div>

        {/* Benefits Section */}
        <div className="mt-24 grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8 animate-slideInLeft">
            <h3 className="text-4xl md:text-5xl font-black text-foreground">
              Health Benefits of
              <span className="honey-text-gradient block">Pure Honey</span>
            </h3>
            
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                  <i className="fas fa-heart text-primary-foreground"></i>
                </div>
                <div>
                  <h4 className="text-xl font-semibold text-foreground mb-2">Antioxidant Rich</h4>
                  <p className="text-muted-foreground">Packed with natural antioxidants that support overall health and wellness.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                  <i className="fas fa-shield-alt text-primary-foreground"></i>
                </div>
                <div>
                  <h4 className="text-xl font-semibold text-foreground mb-2">Natural Immunity</h4>
                  <p className="text-muted-foreground">Boosts immune system with natural antibacterial properties.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                  <i className="fas fa-leaf text-primary-foreground"></i>
                </div>
                <div>
                  <h4 className="text-xl font-semibold text-foreground mb-2">Pure & Natural</h4>
                  <p className="text-muted-foreground">No artificial additives or processing - just pure, natural sweetness.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="relative animate-slideInRight">
            <img 
              src="https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400" 
              alt="Golden honey drops falling with perfect clarity and amber coloring" 
              className="w-full h-96 object-cover rounded-3xl shadow-2xl" 
            />
            
            {/* Floating stats */}
            <div className="absolute -top-6 -right-6 bg-card rounded-2xl p-4 shadow-xl border border-border">
              <div className="text-2xl font-bold text-primary">100%</div>
              <div className="text-sm text-muted-foreground">Pure</div>
            </div>
            
            <div className="absolute -bottom-6 -left-6 bg-card rounded-2xl p-4 shadow-xl border border-border">
              <div className="text-2xl font-bold text-primary">0</div>
              <div className="text-sm text-muted-foreground">Additives</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
