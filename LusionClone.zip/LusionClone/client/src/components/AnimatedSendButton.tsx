import { useState, useEffect } from "react";

interface AnimatedSendButtonProps {
  isLoading: boolean;
  disabled: boolean;
}

export default function AnimatedSendButton({ isLoading, disabled }: AnimatedSendButtonProps) {
  const [isAnimating, setIsAnimating] = useState(false);

  const handleClick = () => {
    if (!disabled && !isLoading) {
      setIsAnimating(true);
      
      // Reset animation after completion
      setTimeout(() => {
        setIsAnimating(false);
      }, 2000);
    }
  };

  useEffect(() => {
    if (typeof window !== "undefined" && window.gsap && isAnimating) {
      const tl = window.gsap.timeline();
      
      tl.to('.send-icon', {
        duration: 0.4,
        x: -8,
        y: 8,
        ease: "power2.out"
      })
      .to('.send-icon', {
        duration: 0.4,
        x: '50vw',
        y: '-50vh',
        ease: "power2.in"
      })
      .set('.send-icon', {
        x: '-50vw',
        y: '50vh'
      })
      .to('.send-icon', {
        duration: 0.3,
        x: 0,
        y: 0,
        ease: "power2.out"
      });
    }
  }, [isAnimating]);

  return (
    <button 
      type="submit"
      onClick={handleClick}
      disabled={disabled}
      className="group relative w-full bg-primary hover:bg-primary/80 text-primary-foreground py-4 rounded-2xl font-semibold text-lg transition-all duration-300 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed overflow-hidden"
    >
      <span className="flex items-center justify-center">
        <span className="mr-3">
          {isLoading ? "Sending..." : "Send Sweet Message"}
        </span>
        <svg 
          className="send-icon w-5 h-5 transition-transform duration-300 group-hover:translate-x-1"
          viewBox="0 0 512 512" 
          fill="currentColor"
        >
          <path d="M511.658 51.675c2.496-11.619-8.895-21.416-20.007-17.176l-482 184a15 15 0 00-.054 28.006L145 298.8v164.713a15 15 0 0028.396 6.75l56.001-111.128 136.664 101.423c8.313 6.17 20.262 2.246 23.287-7.669C516.947 34.532 511.431 52.726 511.658 51.675zm-118.981 52.718L157.874 271.612 56.846 232.594zM175 296.245l204.668-145.757c-176.114 185.79-166.916 176.011-167.684 177.045-1.141 1.535 1.985-4.448-36.984 72.882zm191.858 127.546l-120.296-89.276 217.511-229.462z" />
        </svg>
      </span>
      
      {/* Ripple effect */}
      <div className="absolute inset-0 overflow-hidden rounded-2xl">
        <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/20 to-white/0 transform -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
      </div>
    </button>
  );
}
