import { useEffect, useRef } from "react";

export default function ParallaxCarousel() {
  const containerRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (typeof window === "undefined" || !window.gsap) return;

    const images = [
      "https://images.unsplash.com/photo-1587049352846-4a222e784d38?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      "https://images.unsplash.com/photo-1471943311424-646960669fbc?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      "https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      "https://images.unsplash.com/photo-1516862443072-c8c9c4c9c6d3?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      "https://images.unsplash.com/photo-1587049352846-4a222e784d38?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      "https://images.unsplash.com/photo-1471943311424-646960669fbc?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      "https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      "https://images.unsplash.com/photo-1516862443072-c8c9c4c9c6d3?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      "https://images.unsplash.com/photo-1587049352846-4a222e784d38?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      "https://images.unsplash.com/photo-1471943311424-646960669fbc?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    ];

    let xPos = 0;

    // Setup initial state
    window.gsap.set(ringRef.current, { rotationY: 180, cursor: 'grab' });
    
    // Position images in 3D ring
    const imgElements = ringRef.current?.querySelectorAll('.carousel-img');
    if (imgElements) {
      window.gsap.set(imgElements, {
        rotateY: (i: number) => i * -36,
        transformOrigin: '50% 50% 500px',
        z: -500,
        backgroundImage: (i: number) => `url(${images[i % images.length]})`,
        backgroundPosition: (i: number) => getBgPos(i),
        backfaceVisibility: 'hidden'
      });

      // Entrance animation
      window.gsap.from(imgElements, {
        duration: 1.5,
        y: 200,
        opacity: 0,
        stagger: 0.1,
        ease: 'expo'
      });
    }

    // Drag functionality
    const handleMouseDown = (e: MouseEvent | TouchEvent) => {
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      xPos = Math.round(clientX);
      
      if (ringRef.current) {
        window.gsap.set(ringRef.current, { cursor: 'grabbing' });
      }
      
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('touchmove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      document.addEventListener('touchend', handleMouseUp);
    };

    const handleMouseMove = (e: MouseEvent | TouchEvent) => {
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const deltaX = Math.round(clientX) - xPos;
      
      if (ringRef.current) {
        window.gsap.to(ringRef.current, {
          rotationY: `-=${deltaX}`,
          onUpdate: () => {
            const imgElements = ringRef.current?.querySelectorAll('.carousel-img');
            if (imgElements) {
              window.gsap.set(imgElements, {
                backgroundPosition: (i: number) => getBgPos(i)
              });
            }
          }
        });
      }
      
      xPos = Math.round(clientX);
    };

    const handleMouseUp = () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('touchmove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('touchend', handleMouseUp);
      
      if (ringRef.current) {
        window.gsap.set(ringRef.current, { cursor: 'grab' });
      }
    };

    const getBgPos = (i: number) => {
      if (!ringRef.current) return '0px 0px';
      const rotation = window.gsap.getProperty(ringRef.current, 'rotationY') as number;
      return `${100 - ((rotation - 180 - i * 36) % 360) / 360 * 500}px 0px`;
    };

    // Add event listeners
    if (containerRef.current) {
      containerRef.current.addEventListener('mousedown', handleMouseDown);
      containerRef.current.addEventListener('touchstart', handleMouseDown);
    }

    return () => {
      if (containerRef.current) {
        containerRef.current.removeEventListener('mousedown', handleMouseDown);
        containerRef.current.removeEventListener('touchstart', handleMouseDown);
      }
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('touchmove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('touchend', handleMouseUp);
    };
  }, []);

  return (
    <div className="py-16">
      <div className="text-center mb-12">
        <h3 className="text-3xl md:text-4xl font-black text-foreground">
          Our Honey
          <span className="honey-text-gradient block">Gallery</span>
        </h3>
        <p className="text-muted-foreground mt-4">Drag to explore our collection</p>
      </div>
      
      <div 
        ref={containerRef}
        className="relative w-full h-96 flex items-center justify-center"
        style={{ perspective: '2000px' }}
      >
        <div 
          ref={ringRef}
          className="relative w-80 h-64"
          style={{ transformStyle: 'preserve-3d' }}
        >
          {Array.from({ length: 10 }, (_, i) => (
            <div
              key={i}
              className="carousel-img absolute inset-0 w-full h-full bg-cover bg-center rounded-xl shadow-lg"
              style={{ transformStyle: 'preserve-3d' }}
            ></div>
          ))}
        </div>
      </div>
    </div>
  );
}
