import { useEffect, useRef } from "react";

export default function HoneyBenefitsSection() {
  const containerRef = useRef<HTMLDivElement>(null);

  const benefitsData = [
    {
      title: "Natural Energy Boost",
      description: "Honey provides quick, sustained energy through natural fructose and glucose. Perfect for athletes and active lifestyles without the crash of processed sugars.",
      icon: "⚡",
      category: "Energy & Performance"
    },
    {
      title: "Immune System Support",
      description: "Rich in antioxidants, enzymes, and antimicrobial compounds that strengthen your body's natural defenses against illness and infection.",
      icon: "🛡️",
      category: "Health & Immunity"
    },
    {
      title: "Digestive Wellness",
      description: "Prebiotic properties promote healthy gut bacteria, improve digestion, and soothe stomach irritation naturally.",
      icon: "🌿",
      category: "Digestive Health"
    },
    {
      title: "Skin & Beauty",
      description: "Natural humectant properties hydrate and heal skin, reduce inflammation, and provide anti-aging benefits when consumed regularly.",
      icon: "✨",
      category: "Beauty & Wellness"
    }
  ];

  const benefits = [
    {
      title: "Natural Energy",
      description: "Pure fructose and glucose provide sustained energy without blood sugar spikes",
      icon: "⚡"
    },
    {
      title: "Immune Support",
      description: "Rich in antioxidants and antimicrobial compounds that boost natural immunity",
      icon: "🛡️"
    },
    {
      title: "Digestive Health",
      description: "Prebiotic properties support healthy gut bacteria and digestion",
      icon: "🌿"
    },
    {
      title: "Skin & Beauty",
      description: "Natural humectant properties hydrate and nourish skin from within",
      icon: "✨"
    },
    {
      title: "Sleep Quality",
      description: "Natural sugars help produce serotonin, promoting restful sleep",
      icon: "🌙"
    },
    {
      title: "Heart Health",
      description: "Antioxidants support cardiovascular health and circulation",
      icon: "❤️"
    }
  ];

  useEffect(() => {
    const script1 = document.createElement('script');
    script1.src = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js';
    document.head.appendChild(script1);

    script1.onload = () => {
      const script2 = document.createElement('script');
      script2.src = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js';
      document.head.appendChild(script2);

      script2.onload = () => {
        if (window.gsap && window.ScrollTrigger) {
          window.gsap.registerPlugin(window.ScrollTrigger);
          
          setTimeout(() => {
            const timelineItems = document.querySelectorAll('.timeline-item');
            
            window.gsap.set(timelineItems, {
              x: (i: number) => i % 2 === 0 ? -100 : 100,
              opacity: 0
            });

            window.ScrollTrigger.create({
              trigger: '.benefits-container',
              start: "top 70%",
              onEnter: () => {
                window.gsap.to(timelineItems, {
                  x: 0,
                  opacity: 1,
                  duration: 1,
                  stagger: 0.3,
                  ease: "power3.out"
                });
              }
            });
          }, 500);
        }
      };
    };
  }, []);

  return (
    <section id="benefits" className="py-32 bg-gradient-to-br from-amber-50 via-honey-50 to-orange-50 dark:from-gray-900 dark:via-gray-950 dark:to-gray-900 relative overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-20 right-10 w-6 h-6 bg-amber-400/20 rounded-full animate-float"></div>
        <div className="absolute bottom-32 left-20 w-8 h-8 bg-orange-400/20 rounded-full animate-float" style={{animationDelay: '-3s'}}></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <div className="text-sm font-semibold text-primary tracking-widest uppercase mb-4">Health & Wellness</div>
          <h2 className="text-5xl md:text-6xl font-black text-foreground mb-6">
            Honey
            <span className="block honey-text-gradient">Benefits</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Discover the incredible health benefits of pure honey, nature's most powerful superfood for your body and mind.
          </p>
        </div>

        {/* Timeline */}
        <div className="benefits-container mb-32">
          <div className="relative">
            <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-primary to-orange-400 transform -translate-x-1/2"></div>
            
            {benefitsData.map((item, index) => (
              <div key={index} className={`timeline-item relative flex items-center mb-16 ${index % 2 === 0 ? 'justify-start' : 'justify-end'}`}>
                <div className={`w-5/12 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8 text-left'}`}>
                  <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-8 shadow-lg border border-primary/20">
                    <div className="flex items-center gap-4 mb-4">
                      <span className="text-3xl">{item.icon}</span>
                      <div>
                        <div className="text-sm font-semibold text-primary">{item.category}</div>
                        <div className="text-lg font-bold text-foreground">{item.title}</div>
                      </div>
                    </div>
                    <p className="text-muted-foreground">{item.description}</p>
                  </div>
                </div>
                
                <div className="absolute left-1/2 top-1/2 w-6 h-6 bg-primary rounded-full border-4 border-background transform -translate-x-1/2 -translate-y-1/2 shadow-lg"></div>
              </div>
            ))}
          </div>
        </div>

        {/* Benefits Section */}
        <div className="benefits-container">
          <div className="text-center mb-16">
            <h3 className="text-4xl md:text-5xl font-black text-foreground mb-6">
              Nature's Perfect
              <span className="block honey-text-gradient">Medicine</span>
            </h3>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Modern science confirms what our ancestors knew - honey is a powerhouse of health benefits.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="benefit-item bg-card/60 backdrop-blur-sm rounded-2xl p-8 shadow-lg border border-primary/10 hover:border-primary/30 transition-all duration-500 group">
                <div className="text-4xl mb-6 group-hover:scale-110 transition-transform duration-300">
                  {benefit.icon}
                </div>
                <h4 className="text-xl font-bold text-foreground mb-4">{benefit.title}</h4>
                <p className="text-muted-foreground leading-relaxed">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center mt-20">
          <div className="bg-gradient-to-r from-primary to-orange-400 rounded-3xl p-12 text-white">
            <h3 className="text-3xl md:text-4xl font-black mb-6">
              Experience Ancient Wisdom Today
            </h3>
            <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
              Join thousands of years of tradition with our premium, raw honey collection
            </p>
            <button className="bg-white text-primary px-8 py-4 rounded-full font-semibold text-lg hover:bg-white/90 transition-all duration-300 transform hover:scale-105 shadow-lg">
              Shop Our Collection
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}