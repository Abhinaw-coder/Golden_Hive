import { useEffect, useRef } from "react";

export default function ThreeScene() {
  const containerRef = useRef<HTMLDivElement>(null);
  const beeRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Hide default cursor
    document.body.style.cursor = "none";
    
    // Create bee cursor
    const createBeeCursor = () => {
      const beeElement = document.createElement("div");
      beeElement.className = "fixed w-8 h-8 pointer-events-none z-50 transition-all duration-200 ease-out";
      beeElement.innerHTML = `
        <div class="w-full h-full bg-primary rounded-full shadow-lg flex items-center justify-center text-lg transform -translate-x-1/2 -translate-y-1/2">
          🐝
        </div>
      `;
      beeElement.style.left = "0px";
      beeElement.style.top = "0px";
      
      document.body.appendChild(beeElement);
      
      return beeElement;
    };

    // Initialize bee cursor
    const bee = createBeeCursor();
    
    // Mouse movement handler
    const handleMouseMove = (e: MouseEvent) => {
      if (bee) {
        bee.style.left = e.clientX + "px";
        bee.style.top = e.clientY + "px";
      }
    };

    // Mouse enter/leave handlers for hover effects
    const handleMouseEnter = () => {
      if (bee && typeof window !== "undefined" && window.gsap) {
        window.gsap.to(bee.firstElementChild, {
          scale: 1.5,
          duration: 0.3,
          ease: "back.out(1.7)"
        });
      }
    };

    const handleMouseLeave = () => {
      if (bee && typeof window !== "undefined" && window.gsap) {
        window.gsap.to(bee.firstElementChild, {
          scale: 1,
          duration: 0.3,
          ease: "back.out(1.7)"
        });
      }
    };

    // Add event listeners
    document.addEventListener("mousemove", handleMouseMove);
    
    // Add hover effects to interactive elements
    const interactiveElements = document.querySelectorAll("button, a, input, textarea, select, [role='button']");
    interactiveElements.forEach(el => {
      el.addEventListener("mouseenter", handleMouseEnter);
      el.addEventListener("mouseleave", handleMouseLeave);
    });

    return () => {
      document.body.style.cursor = "auto";
      document.removeEventListener("mousemove", handleMouseMove);
      
      interactiveElements.forEach(el => {
        el.removeEventListener("mouseenter", handleMouseEnter);
        el.removeEventListener("mouseleave", handleMouseLeave);
      });
      
      if (bee && bee.parentNode) {
        bee.parentNode.removeChild(bee);
      }
    };
  }, []);

  return (
    <div 
      ref={containerRef}
      className="fixed inset-0 pointer-events-none z-10"
    ></div>
  );
}
