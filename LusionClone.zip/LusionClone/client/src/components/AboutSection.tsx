export default function AboutSection() {
  return (
    <section id="about" className="py-32 relative overflow-hidden">
      <div className="absolute inset-0">
        {/* Creative flowing honey pattern */}
        <svg className="absolute top-0 right-0 w-full h-full opacity-10" viewBox="0 0 1200 800" fill="none">
          <path d="M800 100C900 200 1000 300 1100 200C1200 100 1300 400 1200 500C1100 600 900 700 800 600C700 500 600 400 700 300C800 200 800 100 800 100Z" fill="url(#honeyGradient)" />
          <defs>
            <linearGradient id="honeyGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="hsl(35, 91%, 55%)" />
              <stop offset="100%" stopColor="hsl(45, 100%, 70%)" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8 animate-slideInLeft">
            <div className="text-sm font-semibold text-primary tracking-widest uppercase">About Our Craft</div>
            
            <h2 className="text-5xl md:text-6xl lg:text-7xl font-black text-foreground leading-tight">
              Connecting Ideals to
              <span className="honey-text-gradient block">Uniquely Crafted</span>
              <span className="block">Experiences</span>
            </h2>

            <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
              <p>
                At Golden Hive, we don't follow trends for the sake of it. We believe in a different approach - one that's centered around you, your audience, and the art of creating a memorable, personalized experience.
              </p>
              
              <p>
                Our commitment goes beyond fleeting trends; it's about crafting tailor-made honey experiences that resonate uniquely and leave a lasting impact on every palate.
              </p>
            </div>

            <div className="flex flex-wrap gap-6">
              <div className="bg-card rounded-2xl p-6 shadow-lg border border-border hover:shadow-xl transition-shadow duration-300">
                <div className="text-3xl font-bold text-primary mb-2">15+</div>
                <div className="text-muted-foreground">Years of Craftsmanship</div>
              </div>
              
              <div className="bg-card rounded-2xl p-6 shadow-lg border border-border hover:shadow-xl transition-shadow duration-300">
                <div className="text-3xl font-bold text-primary mb-2">50K+</div>
                <div className="text-muted-foreground">Happy Customers</div>
              </div>
            </div>
          </div>

          <div className="relative animate-slideInRight">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Sustainable honey farm with beehives in golden hour lighting" 
                className="w-full h-96 object-cover" 
              />
              
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
              
              <div className="absolute bottom-6 left-6 text-white">
                <h3 className="text-2xl font-bold mb-2">Sustainable Beekeeping</h3>
                <p className="text-white/80">Harmony with nature since 2008</p>
              </div>
            </div>

            {/* Floating elements */}
            <div className="absolute -top-6 -right-6 w-12 h-12 bg-primary rounded-full animate-float shadow-lg"></div>
            <div className="absolute -bottom-6 -left-6 w-8 h-8 bg-orange-500 rounded-full animate-float shadow-lg" style={{animationDelay: '-2s'}}></div>
          </div>
        </div>
      </div>
    </section>
  );
}
