import { useEffect, useRef } from "react";

interface MarblingCardProps {
  children: React.ReactNode;
  className?: string;
}

export default function MarblingCard({ children, className = "" }: MarblingCardProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas size
    const resizeCanvas = () => {
      const rect = container.getBoundingClientRect();
      canvas.width = rect.width;
      canvas.height = rect.height;
    };

    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);

    // Marbling effect variables
    let mouseX = 0;
    let mouseY = 0;
    let time = 0;

    // Animation loop
    const animate = () => {
      time += 0.02;
      
      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Create marbling effect
      const gradient = ctx.createRadialGradient(
        mouseX, mouseY, 0,
        mouseX, mouseY, 150
      );
      
      gradient.addColorStop(0, `hsla(35, 91%, 55%, ${0.1 + Math.sin(time) * 0.05})`);
      gradient.addColorStop(0.5, `hsla(45, 100%, 70%, ${0.05 + Math.cos(time * 1.5) * 0.03})`);
      gradient.addColorStop(1, "transparent");
      
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      requestAnimationFrame(animate);
    };

    // Mouse move handler
    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      mouseX = e.clientX - rect.left;
      mouseY = e.clientY - rect.top;
    };

    container.addEventListener("mousemove", handleMouseMove);
    animate();

    return () => {
      window.removeEventListener("resize", resizeCanvas);
      container.removeEventListener("mousemove", handleMouseMove);
    };
  }, []);

  return (
    <div 
      ref={containerRef}
      className={`marbling-container relative ${className}`}
    >
      <canvas 
        ref={canvasRef}
        className="marbling-canvas"
      />
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
}
