import { useEffect, useRef } from "react";

export default function ChartsSection() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const script1 = document.createElement('script');
    script1.src = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js';
    document.head.appendChild(script1);

    script1.onload = () => {
      const script2 = document.createElement('script');
      script2.src = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js';
      document.head.appendChild(script2);

      script2.onload = () => {
        if (window.gsap && window.ScrollTrigger) {
          window.gsap.registerPlugin(window.ScrollTrigger);
          
          setTimeout(() => {
            const chartCards = document.querySelectorAll('.chart-card');
            
            window.gsap.set(chartCards, {
              y: 50,
              opacity: 0,
              scale: 0.95
            });

            window.ScrollTrigger.create({
              trigger: '#charts',
              start: "top 70%",
              onEnter: () => {
                window.gsap.to(chartCards, {
                  y: 0,
                  opacity: 1,
                  scale: 1,
                  duration: 0.8,
                  stagger: 0.2,
                  ease: "power3.out"
                });
              }
            });
          }, 500);
        }
      };
    };
  }, []);

  return (
    <section id="charts" className="py-32 bg-gradient-to-br from-gray-50 via-white to-honey-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 relative overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-4 h-4 bg-primary/20 rounded-full animate-float"></div>
        <div className="absolute bottom-32 right-20 w-6 h-6 bg-orange-400/20 rounded-full animate-float" style={{animationDelay: '-2s'}}></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <div className="text-sm font-semibold text-primary tracking-widest uppercase mb-4">Industry Insights</div>
          <h2 className="text-5xl md:text-6xl font-black text-foreground mb-6">
            Honey
            <span className="block honey-text-gradient">Analytics</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Discover the latest trends and insights in honey production and market performance across the industry.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20">
          <div className="chart-card bg-card/80 backdrop-blur-sm rounded-3xl p-8 shadow-lg border border-primary/20 hover:shadow-xl transition-all duration-300">
            <div className="mb-6">
              <h3 className="text-2xl font-bold text-foreground mb-3">Honey Production Trends</h3>
              <p className="text-muted-foreground">Annual honey production statistics showing global market growth and regional distribution patterns.</p>
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-inner">
              <img 
                src="https://i0.wp.com/rankingroyals.com/wp-content/uploads/2023/05/Honey-Production.png?fit=3375%2C4219&ssl=1" 
                alt="Honey production statistics and trends chart showing annual growth patterns" 
                className="w-full h-auto rounded-xl shadow-lg"
                loading="lazy"
              />
            </div>
          </div>

          <div className="chart-card bg-card/80 backdrop-blur-sm rounded-3xl p-8 shadow-lg border border-primary/20 hover:shadow-xl transition-all duration-300">
            <div className="mb-6">
              <h3 className="text-2xl font-bold text-foreground mb-3">Market Performance</h3>
              <p className="text-muted-foreground">Comprehensive analysis of honey market performance across different segments and consumer preferences.</p>
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-inner">
              <img 
                src="https://thirdspacelearning.com/wp-content/uploads/2023/08/Bar-Graph-Image-3-US.png" 
                alt="Bar graph showing honey market performance and consumer trends analysis" 
                className="w-full h-auto rounded-xl shadow-lg"
                loading="lazy"
              />
            </div>
          </div>
        </div>

        <div className="text-center">
          <div className="bg-gradient-to-r from-primary to-orange-400 rounded-3xl p-12 text-white">
            <h3 className="text-3xl md:text-4xl font-black mb-6">
              Data-Driven Excellence
            </h3>
            <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
              Our commitment to quality is backed by industry-leading analytics and continuous market research
            </p>
            <button className="bg-white text-primary px-8 py-4 rounded-full font-semibold text-lg hover:bg-white/90 transition-all duration-300 transform hover:scale-105 shadow-lg">
              View Full Report
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}