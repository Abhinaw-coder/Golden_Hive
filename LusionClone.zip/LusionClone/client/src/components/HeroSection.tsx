import BubbleAnimation from "./BubbleAnimation";

export default function HeroSection() {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden pt-20">
      <div className="absolute inset-0 bg-gradient-to-br from-honey-50 via-background to-orange-50 dark:from-gray-900 dark:via-background dark:to-gray-900"></div>
      
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-32 -right-32 w-64 h-64 bg-primary/20 rounded-full animate-float"></div>
        <div className="absolute -bottom-32 -left-32 w-96 h-96 bg-orange-300/20 rounded-full animate-float" style={{animationDelay: '-2s'}}></div>
        <div className="absolute top-1/2 right-1/4 w-32 h-32 bg-primary/30 rounded-full animate-float" style={{animationDelay: '-4s'}}></div>
      </div>

      {/* Bubble Animation Container */}
      <BubbleAnimation />

      <div className="max-w-7xl mx-auto px-6 text-center relative z-20">
        <div className="animate-fadeInUp">
          <h1 className="text-6xl md:text-8xl lg:text-9xl font-black text-foreground mb-6 leading-none tracking-tight">
            PURE
            <span className="block honey-text-gradient">GOLDEN</span>
            <span className="block">HONEY</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground mb-12 max-w-3xl mx-auto leading-relaxed">
            Experience the finest artisan honey crafted with passion, 
            <br className="hidden md:block" />connecting nature's sweetness to uniquely crafted experiences.
          </p>

          <div className="flex justify-center mb-16">
            <button 
              onClick={() => {
                const element = document.getElementById("benefits");
                if (element) {
                  element.scrollIntoView({ behavior: "smooth", block: "start" });
                }
              }}
              className="group border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300"
            >
              DISCOVER MORE
            </button>
          </div>

          {/* Scroll Indicator */}
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
            <div className="w-6 h-10 border-2 border-primary rounded-full flex justify-center">
              <div className="w-1 h-3 bg-primary rounded-full mt-2 animate-pulse"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
