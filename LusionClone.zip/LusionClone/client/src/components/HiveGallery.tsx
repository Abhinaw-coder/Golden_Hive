import { useEffect } from "react";

export default function HiveGallery() {
  const images = [
    'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=650&fm=jpg',
    'https://images.unsplash.com/photo-1497733942558-e74c87ef89db?w=650&fm=jpg', 
    'https://images.unsplash.com/photo-1540744276164-9dc898353c7b?w=650&fm=jpg',
    'https://images.unsplash.com/photo-1469975692758-66d107a536cb?w=650&fm=jpg',
    'https://images.unsplash.com/photo-1490845060161-85f9ce08a9f4?w=650&fm=jpg',
    'https://images.unsplash.com/photo-1541673504494-8bcc1a340180?w=650&fm=jpg',
    'https://images.unsplash.com/photo-1515937350506-3e7b51a95339?w=650&fm=jpg',
    'https://images.unsplash.com/photo-1587049352846-4a222e784d38?ixlib=rb-4.0.3&auto=format&fit=crop&w=650&h=650',
    'https://images.unsplash.com/photo-1471943311424-646960669fbc?ixlib=rb-4.0.3&auto=format&fit=crop&w=650&h=650'
  ];

  const nRows = 3;
  const nColsMin = 2;
  const nColsMax = nColsMin + 1;
  const nColsSum = nColsMax + nColsMin;
  const n = Math.ceil(0.5 * nRows) * nColsMin + Math.floor(0.5 * nRows) * nColsMax;

  useEffect(() => {
    const script1 = document.createElement('script');
    script1.src = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js';
    document.head.appendChild(script1);

    script1.onload = () => {
      const script2 = document.createElement('script');
      script2.src = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js';
      document.head.appendChild(script2);

      script2.onload = () => {
        if (window.gsap && window.ScrollTrigger) {
          window.gsap.registerPlugin(window.ScrollTrigger);
          
          setTimeout(() => {
            const hexCells = document.querySelectorAll('.hex-cell');
            
            window.gsap.set(hexCells, {
              scale: 0,
              opacity: 0,
              rotation: 180
            });

            window.ScrollTrigger.create({
              trigger: '.hive-gallery',
              start: "top 70%",
              onEnter: () => {
                window.gsap.to(hexCells, {
                  scale: 0.95,
                  opacity: 1,
                  rotation: 0,
                  duration: 1,
                  stagger: 0.1,
                  ease: "back.out(1.7)"
                });
              }
            });
          }, 500);
        }
      };
    };
  }, []);

  return (
    <section id="gallery" className="py-32 bg-gradient-to-br from-honey-50 via-orange-50 to-yellow-50 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950 relative overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-10 left-10 w-4 h-4 bg-primary/30 rounded-full animate-float"></div>
        <div className="absolute top-32 right-20 w-6 h-6 bg-orange-400/30 rounded-full animate-float" style={{animationDelay: '-2s'}}></div>
        <div className="absolute bottom-20 left-1/4 w-5 h-5 bg-yellow-400/30 rounded-full animate-float" style={{animationDelay: '-4s'}}></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <div className="text-sm font-semibold text-primary tracking-widest uppercase mb-4">Visual Journey</div>
          <h2 className="text-5xl md:text-6xl font-black text-foreground mb-6">
            Hive
            <span className="block honey-text-gradient">Gallery</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Experience the beauty of our honey collection arranged in nature's perfect hexagonal pattern
          </p>
        </div>

        <div 
          className="hive-gallery"
          style={{
            '--n-rows': nRows,
            '--n-cols': 2 * nColsMax,
            '--l': 'calc(100vmin/var(--n-cols))',
            '--hl': 'calc(0.5*var(--l))',
            '--ri': 'calc(0.5*1.732*var(--l))',
            display: 'grid',
            placeContent: 'center',
            gridTemplate: `repeat(${nRows}, var(--l)) / repeat(${2 * nColsMax}, var(--ri))`,
            gridGap: 'var(--hl) 0',
            padding: 'var(--hl) 0',
            minHeight: '60vh',
            filter: 'drop-shadow(2px 2px 10px rgba(245, 158, 11, 0.3))'
          } as React.CSSProperties}
        >
          <style>
            {`
              .hex-cell:nth-of-type(${nColsSum}n + 1) { 
                grid-column-start: 2; 
              }
            `}
          </style>
          
          {Array.from({ length: n }, (_, i) => (
            <div
              key={i}
              className="hex-cell"
              style={{
                overflow: 'hidden',
                gridColumnEnd: 'span 2',
                margin: 'calc(-1*var(--hl)) 0',
                clipPath: 'polygon(50% 0, 100% 25%, 100% 75%, 50% 100%, 0 75%, 0 25%)',
                transform: 'scale(0.95)',
                transition: 'all 0.7s ease'
              }}
            >
              <img
                src={images[i % images.length]}
                alt={`Honey gallery image ${i + 1}`}
                style={{
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover',
                  transform: 'scale(1)',
                  filter: 'brightness(0.8)',
                  transition: 'all 0.7s ease'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'scale(1.2)';
                  e.currentTarget.style.filter = 'brightness(1)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'scale(1)';
                  e.currentTarget.style.filter = 'brightness(0.8)';
                }}
              />
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <button className="group bg-primary hover:bg-primary/80 text-primary-foreground px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">
            <span className="flex items-center">
              View Full Collection
              <i className="fas fa-arrow-right ml-3 transform group-hover:translate-x-2 transition-transform duration-300"></i>
            </span>
          </button>
        </div>
      </div>
    </section>
  );
}