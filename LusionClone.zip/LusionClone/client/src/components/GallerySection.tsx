import { useEffect, useRef } from "react";

export default function GallerySection() {
  const containerRef = useRef<HTMLDivElement>(null);

  const honeyImages = [
    {
      url: "https://images.unsplash.com/photo-1587049352846-4a222e784d38?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      title: "Pure Wildflower Honey",
      description: "Golden nectar from mountain meadows"
    },
    {
      url: "https://images.unsplash.com/photo-1471943311424-646960669fbc?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      title: "Organic Clover Honey",
      description: "Raw and unfiltered sweetness"
    },
    {
      url: "https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      title: "Liquid Gold Dripping",
      description: "Nature's perfect sweetness captured"
    },
    {
      url: "https://images.unsplash.com/photo-1516862443072-c8c9c4c9c6d3?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      title: "Honeycomb Perfection",
      description: "Straight from the hive to your table"
    },
    {
      url: "https://images.unsplash.com/photo-1558641796-218b3b5c18d2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      title: "Artisan Honey Jars",
      description: "Handcrafted with care and passion"
    },
    {
      url: "https://images.unsplash.com/photo-1471943311424-646960669fbc?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      title: "Bee Farm Sunrise",
      description: "Where the magic begins each morning"
    }
  ];

  useEffect(() => {
    const script1 = document.createElement('script');
    script1.src = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js';
    document.head.appendChild(script1);

    script1.onload = () => {
      const script2 = document.createElement('script');
      script2.src = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js';
      document.head.appendChild(script2);

      script2.onload = () => {
        if (window.gsap && window.ScrollTrigger) {
          window.gsap.registerPlugin(window.ScrollTrigger);
          
          setTimeout(() => {
            const items = document.querySelectorAll('.gallery-item');
            
            window.gsap.set(items, {
              y: 100,
              opacity: 0,
              scale: 0.8
            });

            window.ScrollTrigger.create({
              trigger: '.gallery-container',
              start: "top 80%",
              onEnter: () => {
                window.gsap.to(items, {
                  y: 0,
                  opacity: 1,
                  scale: 1,
                  duration: 1.2,
                  stagger: 0.15,
                  ease: "back.out(1.7)"
                });
              }
            });
          }, 500);
        }
      };
    };
  }, []);

  return (
    <section id="gallery" className="py-32 bg-gradient-to-br from-honey-50 via-orange-50 to-yellow-50 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950 relative overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-10 left-10 w-4 h-4 bg-primary/30 rounded-full animate-float"></div>
        <div className="absolute top-32 right-20 w-6 h-6 bg-orange-400/30 rounded-full animate-float" style={{animationDelay: '-2s'}}></div>
        <div className="absolute bottom-20 left-1/4 w-5 h-5 bg-yellow-400/30 rounded-full animate-float" style={{animationDelay: '-4s'}}></div>
      </div>

      <div ref={containerRef} className="gallery-container max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <div className="text-sm font-semibold text-primary tracking-widest uppercase mb-4">Visual Journey</div>
          <h2 className="text-5xl md:text-6xl font-black text-foreground mb-6">
            Our Honey
            <span className="block honey-text-gradient">Gallery</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Experience the beauty and craftsmanship behind every drop of our premium honey collection
          </p>
        </div>

        <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
          {honeyImages.map((image, index) => (
            <div
              key={index}
              className="gallery-item break-inside-avoid relative group bg-card rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 cursor-pointer"
            >
              <div className="relative">
                <img 
                  src={image.url}
                  alt={image.title}
                  className="w-full h-auto object-cover transition-transform duration-700 group-hover:scale-110"
                />
                
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-500">
                  <h3 className="text-xl font-bold mb-2">{image.title}</h3>
                  <p className="text-white/80 text-sm">{image.description}</p>
                </div>

                <div className="absolute top-4 right-4 w-12 h-12 border-2 border-white/30 rotate-45 opacity-0 group-hover:opacity-100 group-hover:rotate-90 transition-all duration-700"></div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <button className="group bg-primary hover:bg-primary/80 text-primary-foreground px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">
            <span className="flex items-center">
              View Full Collection
              <i className="fas fa-arrow-right ml-3 transform group-hover:translate-x-2 transition-transform duration-300"></i>
            </span>
          </button>
        </div>
      </div>
    </section>
  );
}