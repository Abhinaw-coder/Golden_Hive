import { useEffect, useState } from "react";
import Preloader from "@/components/Preloader";
import Navigation from "@/components/Navigation";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import ProductsSection from "@/components/ProductsSection";

import HoneyBenefitsSection from "@/components/HoneyBenefitsSection";
import ChartsSection from "@/components/ChartsSection";
import ReviewsSection from "@/components/ReviewsSection";
import ContactSection from "@/components/ContactSection";
import ThreeScene from "@/components/ThreeScene";
import { useScrollTrigger } from "@/hooks/useGSAP";

export default function Home() {
  const [isLoading, setIsLoading] = useState(true);
  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.pageYOffset > 300);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // GSAP ScrollTrigger animations
  useScrollTrigger(
    ".animate-fadeInUp",
    {
      from: { opacity: 0, y: 50 },
      to: { opacity: 1, y: 0, duration: 0.8 },
    }
  );

  useScrollTrigger(
    ".animate-slideInLeft",
    {
      from: { opacity: 0, x: -50 },
      to: { opacity: 1, x: 0, duration: 0.8 },
    }
  );

  useScrollTrigger(
    ".animate-slideInRight",
    {
      from: { opacity: 0, x: 50 },
      to: { opacity: 1, x: 0, duration: 0.8 },
    }
  );

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  if (isLoading) {
    return <Preloader />;
  }

  return (
    <div className="min-h-screen bg-background text-foreground noise-texture">
      <ThreeScene />
      <Navigation />
      
      <main>
        <HeroSection />
        <AboutSection />
        <ProductsSection />
        <HoneyBenefitsSection />
        <ChartsSection />
        <ReviewsSection />
        <ContactSection />
      </main>

      {/* Newsletter Section */}
      <section className="py-24 honey-gradient relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        
        <div className="max-w-4xl mx-auto px-6 text-center relative z-10">
          <div className="animate-fadeInUp">
            <h2 className="text-4xl md:text-5xl font-black text-white mb-6">
              Subscribe to Our
              <span className="block">Sweet Newsletter</span>
            </h2>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Get the latest updates on new honey varieties, exclusive offers, and beekeeping insights delivered to your inbox.
            </p>
            
            <form className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
              <input 
                type="email" 
                placeholder="Enter your email" 
                className="flex-1 px-6 py-4 rounded-full border-0 bg-white/20 backdrop-blur-sm text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-white/50 transition-all" 
              />
              <button 
                type="submit" 
                className="bg-white text-primary px-8 py-4 rounded-full font-semibold hover:bg-white/90 transition-colors duration-300 whitespace-nowrap"
              >
                <i className="fas fa-arrow-right mr-2"></i>
                Subscribe
              </button>
            </form>
          </div>
        </div>
        
        {/* Decorative Elements */}
        <div className="absolute top-0 left-0 w-32 h-32 bg-white/10 rounded-full -translate-x-16 -translate-y-16 animate-float"></div>
        <div className="absolute bottom-0 right-0 w-48 h-48 bg-white/10 rounded-full translate-x-24 translate-y-24 animate-float" style={{animationDelay: '-3s'}}></div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 dark:bg-black text-white py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            <div className="space-y-4">
              <div className="text-2xl font-black text-primary tracking-tight">GOLDEN HIVE</div>
              <p className="text-gray-400 leading-relaxed">
                Crafting premium artisan honey experiences since 2008. Connecting nature's sweetness to your table.
              </p>
              
              <div className="flex space-x-4">
                <a href="#" className="w-10 h-10 bg-primary hover:bg-primary/80 rounded-full flex items-center justify-center transition-colors">
                  <i className="fab fa-instagram"></i>
                </a>
                <a href="#" className="w-10 h-10 bg-primary hover:bg-primary/80 rounded-full flex items-center justify-center transition-colors">
                  <i className="fab fa-facebook"></i>
                </a>
                <a href="#" className="w-10 h-10 bg-primary hover:bg-primary/80 rounded-full flex items-center justify-center transition-colors">
                  <i className="fab fa-twitter"></i>
                </a>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Products</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-primary transition-colors">Wildflower Honey</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Raw Clover Honey</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Premium Gift Sets</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Bulk Orders</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-primary transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Our Story</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Sustainability</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Careers</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-primary transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Shipping Info</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Returns</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">FAQ</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row items-center justify-between">
            <div className="text-gray-400 text-sm">
              © 2024 Golden Hive Creative Studio. All rights reserved.
            </div>
            
            <div className="flex items-center space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-primary text-sm transition-colors">Privacy Policy</a>
              <a href="#" className="text-gray-400 hover:text-primary text-sm transition-colors">Terms of Service</a>
              <div className="text-gray-400 text-sm">Built with ❤️ by Golden Hive</div>
            </div>
          </div>
        </div>
      </footer>

      {/* Back to Top Button */}
      <button 
        onClick={scrollToTop}
        className={`fixed bottom-8 right-8 w-12 h-12 bg-primary hover:bg-primary/80 text-white rounded-full shadow-lg transition-all duration-300 z-30 ${
          showBackToTop ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}
      >
        <i className="fas fa-arrow-up"></i>
      </button>
    </div>
  );
}
