import { useEffect, useRef } from "react";

declare global {
  interface Window {
    gsap: any;
    ScrollTrigger: any;
  }
}

export function useGSAP(callback: () => void, deps: any[] = []) {
  const isRegistered = useRef(false);

  useEffect(() => {
    if (typeof window !== "undefined" && window.gsap) {
      if (!isRegistered.current && window.ScrollTrigger) {
        window.gsap.registerPlugin(window.ScrollTrigger);
        isRegistered.current = true;
      }
      callback();
    }
  }, deps);
}

export function useScrollTrigger(
  trigger: string,
  animation: any,
  options: any = {}
) {
  useEffect(() => {
    if (typeof window !== "undefined" && window.gsap && window.ScrollTrigger) {
      const elements = document.querySelectorAll(trigger);
      
      elements.forEach((element) => {
        window.gsap.fromTo(
          element,
          animation.from,
          {
            ...animation.to,
            scrollTrigger: {
              trigger: element,
              start: "top 80%",
              end: "bottom 20%",
              toggleActions: "play none none reverse",
              ...options,
            },
          }
        );
      });

      return () => {
        window.ScrollTrigger.getAll().forEach((trigger: any) => trigger.kill());
      };
    }
  }, [trigger, animation, options]);
}
